export const MAX_ERROR = 'باید بزرگ تر یا مساوی';

export const STRING_ERROR = 'باید متن باشد';

export const CHARACTER_ERROR = 'باشد';
