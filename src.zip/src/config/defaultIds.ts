export const ADMIN_ROLE_ID = '648897cb9cfe2a028d52c318';
export const ADMIN_EMPLOYEE_ID = '649064d53fa624054dfb0c5a';
export const DEPARTMENT_ID = '648897cb9cfe2a028d52c316';
