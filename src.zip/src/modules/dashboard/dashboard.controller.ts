import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { QueryBus } from '@nestjs/cqrs';

import { GetStudentDashboardQuery } from './handlers/queries/GetStudentDashboard.query';
import { GetTeacherDashboardQuery } from './handlers/queries/GetTeacherDashboard.query';
import { GetAdminDashboardQuery } from './handlers/queries/GetAdminDashboard.query';
import { GetTeacherScheduleQuery } from './handlers/queries/GetTeacherSchedule.query';
import { GetStudentScheduleQuery } from './handlers/queries/GetStudentSchedule.query';
import { GetStudentReportCardQuery } from './handlers/queries/GetStudentReportCard.query';
import { GetAdminProgressQuery } from './handlers/queries/GetAdminProgress.query';
import { JwtGuard } from 'src/guards/jwt.guard';

@Controller('dashboard')
export class DashboardController {
  constructor(private readonly queryBus: QueryBus) {}

  // --- DASHBOARD ---
  @Get('student')
  @UseGuards(JwtGuard)
  async getStudentDashboard(@Req() req) {
    return this.queryBus.execute(new GetStudentDashboardQuery(req.user));
  }

  @Get('teacher')
  @UseGuards(JwtGuard)
  async getTeacherDashboard(@Req() req) {
    return this.queryBus.execute(new GetTeacherDashboardQuery(req.user));
  }

  @Get('admin')
  @UseGuards(JwtGuard)
  async getAdminDashboard(@Req() req) {
    return this.queryBus.execute(new GetAdminDashboardQuery(req.user));
  }

  // --- SCHEDULE ---
  @Get('student/schedule')
  @UseGuards(JwtGuard)
  async getStudentSchedule(@Req() req) {
    return this.queryBus.execute(new GetStudentScheduleQuery(req.user));
  }

  @Get('teacher/schedule')
  @UseGuards(JwtGuard)
  async getTeacherSchedule(@Req() req) {
    return this.queryBus.execute(new GetTeacherScheduleQuery(req.user));
  }

  // --- REPORT CARD ---
  @Get('student/report-card')
  @UseGuards(JwtGuard)
  async getStudentReport(@Req() req) {
    return this.queryBus.execute(new GetStudentReportCardQuery(req.user));
  }

  // --- PROGRESS (ADMIN) ---
  @Get('admin/progress')
  @UseGuards(JwtGuard)
  async getAdminProgress(@Req() req) {
    return this.queryBus.execute(new GetAdminProgressQuery(req.user));
  }
}
