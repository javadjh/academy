export const userTypeEnumSchema = ['admin', 'student', 'teacher'];
export const genderEnumSchema = ['آقا', 'خانم'];
export const weekDayEnumSchema = [
  'شنبه',
  'یکشنبه',
  'دوشنبه',
  'سه شنبه',
  'چهارشنبه',
  'پنجشنبه',
  'جمعه',
];
